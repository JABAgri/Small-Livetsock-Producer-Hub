import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Platform } from 'react-native';
import { Provider as PaperProvider } from 'react-native-paper';
import { Home, Database, FileText, Menu } from 'lucide-react-native';

// Screens
import DashboardScreen from './src/screens/DashboardScreen';
import StockManagementScreen from './src/screens/StockManagementScreen';
import DocumentsScreen from './src/screens/DocumentsScreen';
import MoreScreen from './src/screens/MoreScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <PaperProvider>
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={{
            tabBarStyle: {
              backgroundColor: '#FAF6ED',
              borderTopColor: '#E6DCCA',
              height: Platform.OS === 'ios' ? 85 : 60,
              paddingBottom: Platform.OS === 'ios' ? 25 : 10,
            },
            tabBarActiveTintColor: '#CCAF9B',
            tabBarInactiveTintColor: '#666666',
            headerStyle: {
              backgroundColor: '#FAF6ED',
              borderBottomColor: '#E6DCCA',
              borderBottomWidth: 1,
            },
            headerTintColor: '#333333',
          }}
        >
          <Tab.Screen
            name="Dashboard"
            component={DashboardScreen}
            options={{
              tabBarIcon: ({ color }) => <Home size={24} color={color} />,
            }}
          />
          <Tab.Screen
            name="Stock"
            component={StockManagementScreen}
            options={{
              tabBarIcon: ({ color }) => <Database size={24} color={color} />,
            }}
          />
          <Tab.Screen
            name="Documents"
            component={DocumentsScreen}
            options={{
              tabBarIcon: ({ color }) => <FileText size={24} color={color} />,
            }}
          />
          <Tab.Screen
            name="More"
            component={MoreScreen}
            options={{
              tabBarIcon: ({ color }) => <Menu size={24} color={color} />,
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </PaperProvider>
  );
}