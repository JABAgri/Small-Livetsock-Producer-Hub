import { Observable } from '@nativescript/core';
import { Geolocation } from '@nativescript/geolocation';

export class DashboardViewModel extends Observable {
    constructor() {
        super();
        
        this.recentActivity = [
            {
                icon: '\uf058',
                title: 'NLIS Transfer Completed',
                time: '2 hours ago'
            },
            {
                icon: '\uf111',
                title: 'Vaccination Records Updated',
                time: 'Yesterday'
            }
        ];

        this.initLocation();
    }

    async initLocation() {
        try {
            const hasPermission = await Geolocation.enableLocationRequest();
            if (hasPermission) {
                const location = await Geolocation.getCurrentLocation({
                    desiredAccuracy: 3,
                    maximumAge: 5000,
                    timeout: 10000
                });
                console.log('Location:', location);
            }
        } catch (error) {
            console.error('Error getting location:', error);
        }
    }

    onRecordMovement() {
        // Navigate to movement recording page
    }

    onAddTreatment() {
        // Navigate to treatment page
    }

    onUpdateNLIS() {
        // Navigate to NLIS update page
    }
}

export function onNavigatingTo(args) {
    const page = args.object;
    page.bindingContext = new DashboardViewModel();
}