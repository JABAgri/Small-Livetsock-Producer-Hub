export const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_TOKEN || '';

export const DEFAULT_CENTER = [153.0251, -27.4698]; // Brisbane coordinates
export const DEFAULT_ZOOM = 15;

export const isMapboxConfigured = Boolean(MAPBOX_TOKEN);