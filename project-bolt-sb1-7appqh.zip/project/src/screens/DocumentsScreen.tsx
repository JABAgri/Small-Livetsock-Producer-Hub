import React from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { Text, Card, Button } from 'react-native-paper';
import QRCode from 'react-native-qrcode-svg';
import * as DocumentPicker from 'expo-document-picker';
import { Upload, FileText, Download } from 'lucide-react-native';

export default function DocumentsScreen() {
  const handleDocumentPick = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/*'],
      });
      
      if (result.assets && result.assets.length > 0) {
        // Handle the selected document
        console.log(result.assets[0]);
      }
    } catch (err) {
      console.error('Error picking document:', err);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.cardTitle}>Mobile App Connection</Text>
          <View style={styles.qrContainer}>
            <QRCode
              value="https://play.google.com/store/apps/details?id=com.jabagri.livestockhub"
              size={200}
            />
          </View>
          <Text style={styles.description}>
            Scan this QR code to download our mobile app and sync your documents
          </Text>
          <View style={styles.buttonRow}>
            <Button mode="outlined" style={styles.button}>App Store</Button>
            <Button mode="outlined" style={styles.button}>Play Store</Button>
          </View>
        </Card.Content>
      </Card>

      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.cardTitle}>Upload Documents</Text>
          <Button
            mode="outlined"
            icon={() => <Upload size={24} color="#CCAF9B" />}
            onPress={handleDocumentPick}
            style={styles.uploadButton}
          >
            Select Document
          </Button>
        </Card.Content>
      </Card>

      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.cardTitle}>Recent Documents</Text>
          <View style={styles.documentList}>
            {/* Example document items */}
            <View style={styles.documentItem}>
              <View style={styles.documentInfo}>
                <FileText size={24} color="#CCAF9B" />
                <View style={styles.documentText}>
                  <Text>NVD_12345.pdf</Text>
                  <Text style={styles.timeText}>2 hours ago</Text>
                </View>
              </View>
              <Button
                mode="text"
                icon={() => <Download size={20} color="#CCAF9B" />}
              >
                Download
              </Button>
            </View>
          </View>
        </Card.Content>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAF6ED',
  },
  card: {
    margin: 8,
    backgroundColor: '#FFFFFF',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  qrContainer: {
    alignItems: 'center',
    marginVertical: 16,
  },
  description: {
    textAlign: 'center',
    marginVertical: 12,
    color: '#666666',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  button: {
    flex: 1,
    marginHorizontal: 4,
    borderColor: '#CCAF9B',
  },
  uploadButton: {
    borderColor: '#CCAF9B',
    borderStyle: 'dashed',
    height: 100,
    justifyContent: 'center',
  },
  documentList: {
    marginTop: 8,
  },
  documentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E6DCCA',
  },
  documentInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  documentText: {
    marginLeft: 12,
  },
  timeText: {
    fontSize: 12,
    color: '#666666',
  },
});