import React from 'react';
import { View, ScrollView, StyleSheet, useWindowDimensions } from 'react-native';
import { Text, Card, Button, useTheme } from 'react-native-paper';
import MapView, { Marker } from 'react-native-maps';
import { Clock, AlertTriangle, CheckCircle, Activity } from 'lucide-react-native';
import { Layout } from '../components/Layout';

export default function DashboardScreen() {
  const { width } = useWindowDimensions();
  const theme = useTheme();
  const isTablet = width >= 768;

  return (
    <Layout>
      <ScrollView style={styles.container}>
        {/* Stats Grid */}
        <View style={[styles.statsGrid, isTablet && styles.statsGridTablet]}>
          <Card style={[styles.statsCard, isTablet && styles.statsCardTablet]}>
            <Card.Content>
              <Clock size={isTablet ? 32 : 24} color={theme.colors.primary} />
              <Text style={[styles.statsValue, isTablet && styles.statsValueTablet]}>5</Text>
              <Text style={styles.statsLabel}>Tasks Due</Text>
            </Card.Content>
          </Card>
          
          <Card style={[styles.statsCard, isTablet && styles.statsCardTablet]}>
            <Card.Content>
              <AlertTriangle size={isTablet ? 32 : 24} color={theme.colors.primary} />
              <Text style={[styles.statsValue, isTablet && styles.statsValueTablet]}>2</Text>
              <Text style={styles.statsLabel}>Alerts</Text>
            </Card.Content>
          </Card>
          
          <Card style={[styles.statsCard, isTablet && styles.statsCardTablet]}>
            <Card.Content>
              <CheckCircle size={isTablet ? 32 : 24} color={theme.colors.primary} />
              <Text style={[styles.statsValue, isTablet && styles.statsValueTablet]}>98%</Text>
              <Text style={styles.statsLabel}>Compliance</Text>
            </Card.Content>
          </Card>
          
          <Card style={[styles.statsCard, isTablet && styles.statsCardTablet]}>
            <Card.Content>
              <Activity size={isTablet ? 32 : 24} color={theme.colors.primary} />
              <Text style={[styles.statsValue, isTablet && styles.statsValueTablet]}>245</Text>
              <Text style={styles.statsLabel}>Stock Count</Text>
            </Card.Content>
          </Card>
        </View>

        {/* Map and Actions */}
        <View style={isTablet && styles.splitView}>
          <Card style={[styles.mapCard, isTablet && styles.mapCardTablet]}>
            <Card.Content>
              <Text style={styles.cardTitle}>Property Map</Text>
              <MapView
                style={[styles.map, isTablet && styles.mapTablet]}
                initialRegion={{
                  latitude: -27.4698,
                  longitude: 153.0251,
                  latitudeDelta: 0.0922,
                  longitudeDelta: 0.0421,
                }}
              >
                <Marker
                  coordinate={{
                    latitude: -27.4698,
                    longitude: 153.0251,
                  }}
                />
              </MapView>
            </Card.Content>
          </Card>

          <View style={isTablet && styles.sidePanel}>
            <Card style={styles.actionsCard}>
              <Card.Content>
                <Text style={styles.cardTitle}>Quick Actions</Text>
                <Button 
                  mode="outlined" 
                  style={styles.actionButton}
                  contentStyle={isTablet && styles.actionButtonContentTablet}
                >
                  Record Movement
                </Button>
                <Button 
                  mode="outlined" 
                  style={styles.actionButton}
                  contentStyle={isTablet && styles.actionButtonContentTablet}
                >
                  Add Treatment
                </Button>
                <Button 
                  mode="outlined" 
                  style={styles.actionButton}
                  contentStyle={isTablet && styles.actionButtonContentTablet}
                >
                  Update NLIS
                </Button>
              </Card.Content>
            </Card>
          </View>
        </View>
      </ScrollView>
    </Layout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 8,
  },
  statsGridTablet: {
    padding: 16,
  },
  statsCard: {
    width: '48%',
    margin: '1%',
    backgroundColor: '#FFFFFF',
  },
  statsCardTablet: {
    width: '23%',
    margin: '1%',
    padding: 16,
  },
  statsValue: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 8,
  },
  statsValueTablet: {
    fontSize: 32,
  },
  statsLabel: {
    fontSize: 14,
    color: '#666666',
  },
  splitView: {
    flexDirection: 'row',
    padding: 16,
  },
  mapCard: {
    margin: 8,
    backgroundColor: '#FFFFFF',
  },
  mapCardTablet: {
    flex: 2,
    margin: 0,
    marginRight: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  map: {
    height: 200,
    marginVertical: 8,
    borderRadius: 8,
  },
  mapTablet: {
    height: 400,
  },
  sidePanel: {
    flex: 1,
  },
  actionsCard: {
    margin: 8,
    backgroundColor: '#FFFFFF',
  },
  actionButton: {
    marginVertical: 4,
    borderColor: '#CCAF9B',
  },
  actionButtonContentTablet: {
    height: 48,
  },
});