import React from 'react';
import { useForm } from 'react-hook-form';
import { Card, Button, Input } from '../ui';
import { X } from 'lucide-react';
import { db } from '@/firebase.config';
import { collection, addDoc } from 'firebase/firestore';
import { showSuccess, showError } from '@/lib/utils/toast';

interface AddChemicalFormData {
  productName: string;
  activeIngredient: string;
  batchNumber: string;
  purchaseDate: string;
  expiryDate: string;
  storageLocation: string;
  withholdingPeriod: string;
}

interface AddChemicalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function AddChemicalModal({ isOpen, onClose, onSuccess }: AddChemicalModalProps) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<AddChemicalFormData>();

  const onSubmit = async (data: AddChemicalFormData) => {
    try {
      await addDoc(collection(db, 'chemicals'), {
        ...data,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      showSuccess('Chemical record added successfully');
      reset();
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error adding chemical:', error);
      showError('Failed to add chemical record');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-2xl bg-white">
        <Card.Header className="flex justify-between items-center">
          <h3 className="text-lg font-medium">Add Chemical Record</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </Card.Header>
        <Card.Content>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Product Name</label>
                <Input
                  {...register('productName', { required: 'Product name is required' })}
                  className={errors.productName ? 'border-red-500' : ''}
                />
                {errors.productName && (
                  <p className="text-red-500 text-sm mt-1">{errors.productName.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Active Ingredient</label>
                <Input
                  {...register('activeIngredient', { required: 'Active ingredient is required' })}
                  className={errors.activeIngredient ? 'border-red-500' : ''}
                />
                {errors.activeIngredient && (
                  <p className="text-red-500 text-sm mt-1">{errors.activeIngredient.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Batch Number</label>
                <Input
                  {...register('batchNumber', { required: 'Batch number is required' })}
                  className={errors.batchNumber ? 'border-red-500' : ''}
                />
                {errors.batchNumber && (
                  <p className="text-red-500 text-sm mt-1">{errors.batchNumber.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Purchase Date</label>
                <Input
                  type="date"
                  {...register('purchaseDate', { required: 'Purchase date is required' })}
                  className={errors.purchaseDate ? 'border-red-500' : ''}
                />
                {errors.purchaseDate && (
                  <p className="text-red-500 text-sm mt-1">{errors.purchaseDate.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Expiry Date</label>
                <Input
                  type="date"
                  {...register('expiryDate', { required: 'Expiry date is required' })}
                  className={errors.expiryDate ? 'border-red-500' : ''}
                />
                {errors.expiryDate && (
                  <p className="text-red-500 text-sm mt-1">{errors.expiryDate.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Storage Location</label>
                <Input
                  {...register('storageLocation', { required: 'Storage location is required' })}
                  className={errors.storageLocation ? 'border-red-500' : ''}
                />
                {errors.storageLocation && (
                  <p className="text-red-500 text-sm mt-1">{errors.storageLocation.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Withholding Period</label>
                <Input
                  {...register('withholdingPeriod', { required: 'Withholding period is required' })}
                  className={errors.withholdingPeriod ? 'border-red-500' : ''}
                />
                {errors.withholdingPeriod && (
                  <p className="text-red-500 text-sm mt-1">{errors.withholdingPeriod.message}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit">Add Chemical</Button>
            </div>
          </form>
        </Card.Content>
      </Card>
    </div>
  );
}