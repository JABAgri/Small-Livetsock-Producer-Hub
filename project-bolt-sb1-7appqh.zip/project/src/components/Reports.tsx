import React, { useState } from 'react';
import { Card, Button, Table } from './ui';
import { FileText, Download, BarChart2, Filter, Printer } from 'lucide-react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function Reports() {
  const [selectedReport, setSelectedReport] = useState('stock');
  const [dateRange, setDateRange] = useState('month');

  // Example data for weight tracking chart
  const weightData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Average Weight (kg)',
        data: [45, 48, 52, 55, 58, 62],
        borderColor: '#CCAF9B',
        backgroundColor: 'rgba(204, 175, 155, 0.1)',
        tension: 0.4,
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Stock Weight Progression'
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-gray-900">Reports</h2>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-cream-50">
          <Card.Header>
            <div className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-coffee-400" />
              <h3 className="text-lg font-medium">Stock Reports</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                Inventory Summary
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Movement History
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Treatment Records
              </Button>
            </div>
          </Card.Content>
        </Card>

        <Card className="bg-cream-50">
          <Card.Header>
            <div className="flex items-center space-x-2">
              <BarChart2 className="h-5 w-5 text-coffee-400" />
              <h3 className="text-lg font-medium">Performance</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                Weight Tracking
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Growth Analysis
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Feed Efficiency
              </Button>
            </div>
          </Card.Content>
        </Card>

        <Card className="bg-cream-50">
          <Card.Header>
            <div className="flex items-center space-x-2">
              <Printer className="h-5 w-5 text-coffee-400" />
              <h3 className="text-lg font-medium">Compliance</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                NLIS Compliance
              </Button>
              <Button variant="outline" className="w-full justify-start">
                LPA Audit Report
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Chemical Usage
              </Button>
            </div>
          </Card.Content>
        </Card>

        <Card className="bg-cream-50">
          <Card.Header>
            <div className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-coffee-400" />
              <h3 className="text-lg font-medium">Custom Reports</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                Create Report
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Saved Templates
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Schedule Reports
              </Button>
            </div>
          </Card.Content>
        </Card>
      </div>

      <Card className="bg-cream-50">
        <Card.Header>
          <h3 className="text-lg font-medium">Performance Analytics</h3>
        </Card.Header>
        <Card.Content>
          <div className="h-[400px]">
            <Line options={chartOptions} data={weightData} />
          </div>
        </Card.Content>
      </Card>

      <Card className="bg-cream-50">
        <Card.Header>
          <h3 className="text-lg font-medium">Recent Reports</h3>
        </Card.Header>
        <Card.Content>
          <Table>
            <Table.Header>
              <Table.Row>
                <Table.Head>Report Name</Table.Head>
                <Table.Head>Type</Table.Head>
                <Table.Head>Generated</Table.Head>
                <Table.Head>Status</Table.Head>
                <Table.Head>Actions</Table.Head>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              <Table.Row>
                <Table.Cell>Monthly Stock Summary</Table.Cell>
                <Table.Cell>Inventory</Table.Cell>
                <Table.Cell>2024-02-01</Table.Cell>
                <Table.Cell>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Complete
                  </span>
                </Table.Cell>
                <Table.Cell>
                  <Button variant="ghost" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </Table.Cell>
              </Table.Row>
            </Table.Body>
          </Table>
        </Card.Content>
      </Card>
    </div>
  );
}