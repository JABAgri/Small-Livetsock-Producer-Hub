import React from 'react';
import { useForm } from 'react-hook-form';
import { Card, Button, Input } from '../ui';
import { X } from 'lucide-react';
import { db } from '@/firebase.config';
import { collection, addDoc } from 'firebase/firestore';

interface NLISTransferFormData {
  nvdNumber: string;
  fromPIC: string;
  toPIC: string;
  transferDate: string;
  numberOfHead: number;
  transportDetails: string;
}

interface NLISTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function NLISTransferModal({ isOpen, onClose, onSuccess }: NLISTransferModalProps) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<NLISTransferFormData>();

  const onSubmit = async (data: NLISTransferFormData) => {
    try {
      await addDoc(collection(db, 'nlisTransfers'), {
        ...data,
        status: 'Pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      reset();
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error adding NLIS transfer:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-2xl bg-white">
        <Card.Header className="flex justify-between items-center">
          <h3 className="text-lg font-medium">NLIS Transfer</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </Card.Header>
        <Card.Content>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">NVD Number</label>
                <Input
                  {...register('nvdNumber', { required: 'NVD number is required' })}
                  className={errors.nvdNumber ? 'border-red-500' : ''}
                />
                {errors.nvdNumber && (
                  <p className="text-red-500 text-sm mt-1">{errors.nvdNumber.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">From PIC</label>
                <Input
                  {...register('fromPIC', { required: 'From PIC is required' })}
                  className={errors.fromPIC ? 'border-red-500' : ''}
                />
                {errors.fromPIC && (
                  <p className="text-red-500 text-sm mt-1">{errors.fromPIC.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">To PIC</label>
                <Input
                  {...register('toPIC', { required: 'To PIC is required' })}
                  className={errors.toPIC ? 'border-red-500' : ''}
                />
                {errors.toPIC && (
                  <p className="text-red-500 text-sm mt-1">{errors.toPIC.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Transfer Date</label>
                <Input
                  type="date"
                  {...register('transferDate', { required: 'Transfer date is required' })}
                  className={errors.transferDate ? 'border-red-500' : ''}
                />
                {errors.transferDate && (
                  <p className="text-red-500 text-sm mt-1">{errors.transferDate.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Number of Head</label>
                <Input
                  type="number"
                  {...register('numberOfHead', { 
                    required: 'Number of head is required',
                    min: { value: 1, message: 'Must be at least 1' }
                  })}
                  className={errors.numberOfHead ? 'border-red-500' : ''}
                />
                {errors.numberOfHead && (
                  <p className="text-red-500 text-sm mt-1">{errors.numberOfHead.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Transport Details</label>
                <Input
                  {...register('transportDetails', { required: 'Transport details are required' })}
                  className={errors.transportDetails ? 'border-red-500' : ''}
                />
                {errors.transportDetails && (
                  <p className="text-red-500 text-sm mt-1">{errors.transportDetails.message}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit">Submit Transfer</Button>
            </div>
          </form>
        </Card.Content>
      </Card>
    </div>
  );
}