import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Input } from './ui';
import { Plus, FileText, AlertTriangle, Shield } from 'lucide-react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '@/firebase.config';
import AddChemicalModal from './chemical/AddChemicalModal';
import { format } from 'date-fns';

interface ChemicalRecord {
  id: string;
  productName: string;
  activeIngredient: string;
  batchNumber: string;
  purchaseDate: string;
  expiryDate: string;
  storageLocation: string;
  withholdingPeriod: string;
}

export default function ChemicalRegister() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [chemicals, setChemicals] = useState<ChemicalRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'chemicals'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const chemicalData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as ChemicalRecord[];
      
      setChemicals(chemicalData);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="relative">
        <img 
          src="https://images.unsplash.com/photo-1587049633312-d628ae50a8ae"
          alt="Chemical storage"
          className="w-full h-48 object-cover rounded-lg"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent flex items-center">
          <h2 className="text-2xl font-semibold text-white px-6">Chemical Register</h2>
        </div>
      </div>

      <div className="flex justify-end">
        <Button onClick={() => setIsAddModalOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Chemical Record
        </Button>
      </div>

      <Card>
        <Card.Header>
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Chemical Inventory</h3>
            <Input placeholder="Search chemicals..." className="w-64" />
          </div>
        </Card.Header>
        <Card.Content>
          <Table>
            <Table.Header>
              <Table.Row>
                <Table.Head>Product Name</Table.Head>
                <Table.Head>Active Ingredient</Table.Head>
                <Table.Head>Batch Number</Table.Head>
                <Table.Head>Purchase Date</Table.Head>
                <Table.Head>Expiry Date</Table.Head>
                <Table.Head>Storage Location</Table.Head>
                <Table.Head>Withholding Period</Table.Head>
                <Table.Head>Actions</Table.Head>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              {chemicals.map((chemical) => (
                <Table.Row key={chemical.id}>
                  <Table.Cell>{chemical.productName}</Table.Cell>
                  <Table.Cell>{chemical.activeIngredient}</Table.Cell>
                  <Table.Cell>{chemical.batchNumber}</Table.Cell>
                  <Table.Cell>{format(new Date(chemical.purchaseDate), 'dd/MM/yyyy')}</Table.Cell>
                  <Table.Cell>{format(new Date(chemical.expiryDate), 'dd/MM/yyyy')}</Table.Cell>
                  <Table.Cell>{chemical.storageLocation}</Table.Cell>
                  <Table.Cell>{chemical.withholdingPeriod}</Table.Cell>
                  <Table.Cell>
                    <Button variant="ghost" size="sm">
                      <FileText className="h-4 w-4 mr-1" />
                      Details
                    </Button>
                  </Table.Cell>
                </Table.Row>
              ))}
            </Table.Body>
          </Table>
        </Card.Content>
      </Card>

      <AddChemicalModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSuccess={() => setIsAddModalOpen(false)}
      />
    </div>
  );
}