import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu } from './ui';
import { useAuth } from '@/lib/auth/AuthContext';
import { 
  HomeIcon, 
  BarChart2, 
  FileText, 
  Database, 
  BookOpen, 
  Wrench, 
  Archive, 
  Shield, 
  TestTube, 
  Smartphone,
  LogOut
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [activeView, setActiveView] = React.useState(window.location.pathname.slice(1) || 'dashboard');

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/signin');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const handleNavigation = (path: string) => {
    setActiveView(path);
    navigate(`/${path}`);
  };

  return (
    <div className="min-h-screen bg-cream-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <HomeIcon className="h-8 w-8 text-coffee-400" />
            <h1 className="text-xl font-semibold text-gray-900">Small Livestock Producers Hub</h1>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-900">Welcome, {user?.displayName}</span>
            <button
              onClick={handleLogout}
              className="text-sm text-gray-600 hover:text-gray-900 flex items-center space-x-1"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      <div className="flex min-h-[calc(100vh-4rem)]">
        <aside className="w-64 bg-white shadow-sm">
          <Menu>
            <Menu.Item 
              icon={<BarChart2 />}
              active={activeView === 'dashboard'}
              onClick={() => handleNavigation('dashboard')}
            >
              Dashboard
            </Menu.Item>
            <Menu.Item 
              icon={<Database />}
              active={activeView === 'stock'}
              onClick={() => handleNavigation('stock')}
            >
              Stock Management
            </Menu.Item>
            <Menu.Item
              icon={<FileText />}
              active={activeView === 'nlis'}
              onClick={() => handleNavigation('nlis')}
            >
              NLIS Transfer
            </Menu.Item>
            <Menu.Item 
              icon={<TestTube />}
              active={activeView === 'chemical'}
              onClick={() => handleNavigation('chemical')}
            >
              Chemical Register
            </Menu.Item>
            <Menu.Item 
              icon={<Shield />}
              active={activeView === 'biosecurity'}
              onClick={() => handleNavigation('biosecurity')}
            >
              Biosecurity
            </Menu.Item>
            <Menu.Item 
              icon={<BookOpen />}
              active={activeView === 'education'}
              onClick={() => handleNavigation('education')}
            >
              Education
            </Menu.Item>
            <Menu.Item 
              icon={<Wrench />}
              active={activeView === 'tools'}
              onClick={() => handleNavigation('tools')}
            >
              Tools
            </Menu.Item>
            <Menu.Item 
              icon={<Archive />}
              active={activeView === 'resources'}
              onClick={() => handleNavigation('resources')}
            >
              Resources
            </Menu.Item>
            <Menu.Item 
              icon={<Smartphone />}
              active={activeView === 'documents'}
              onClick={() => handleNavigation('documents')}
            >
              Document Tray
            </Menu.Item>
            <Menu.Item 
              icon={<BarChart2 />}
              active={activeView === 'reports'}
              onClick={() => handleNavigation('reports')}
            >
              Reports
            </Menu.Item>
          </Menu>
        </aside>

        <main className="flex-1 p-8">
          {children}
        </main>
      </div>
    </div>
  );
}