import React from 'react';
import { useForm } from 'react-hook-form';
import { Card, Button, Input } from '../ui';
import { X } from 'lucide-react';
import { db } from '@/firebase.config';
import { collection, addDoc } from 'firebase/firestore';

interface AddStockFormData {
  visualTag: string;
  nlisId: string;
  type: string;
  breed: string;
  sex: string;
  location: string;
  weight: number;
  purchaseCost: number;
  purchaseDate: string;
}

interface AddStockModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function AddStockModal({ isOpen, onClose, onSuccess }: AddStockModalProps) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<AddStockFormData>();

  const onSubmit = async (data: AddStockFormData) => {
    try {
      await addDoc(collection(db, 'stock'), {
        ...data,
        status: 'Active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      reset();
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error adding stock:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-2xl bg-white">
        <Card.Header className="flex justify-between items-center">
          <h3 className="text-lg font-medium">Add New Stock</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </Card.Header>
        <Card.Content>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Visual Tag</label>
                <Input
                  {...register('visualTag', { required: 'Visual tag is required' })}
                  className={errors.visualTag ? 'border-red-500' : ''}
                />
                {errors.visualTag && (
                  <p className="text-red-500 text-sm mt-1">{errors.visualTag.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">NLIS ID</label>
                <Input
                  {...register('nlisId', { required: 'NLIS ID is required' })}
                  className={errors.nlisId ? 'border-red-500' : ''}
                />
                {errors.nlisId && (
                  <p className="text-red-500 text-sm mt-1">{errors.nlisId.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Type</label>
                <select
                  {...register('type', { required: 'Type is required' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-coffee-400 focus:ring focus:ring-coffee-200"
                >
                  <option value="">Select type</option>
                  <option value="Sheep">Sheep</option>
                  <option value="Cattle">Cattle</option>
                  <option value="Goat">Goat</option>
                </select>
                {errors.type && (
                  <p className="text-red-500 text-sm mt-1">{errors.type.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Breed</label>
                <Input
                  {...register('breed', { required: 'Breed is required' })}
                  className={errors.breed ? 'border-red-500' : ''}
                />
                {errors.breed && (
                  <p className="text-red-500 text-sm mt-1">{errors.breed.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Sex</label>
                <select
                  {...register('sex', { required: 'Sex is required' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-coffee-400 focus:ring focus:ring-coffee-200"
                >
                  <option value="">Select sex</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Wether">Wether</option>
                </select>
                {errors.sex && (
                  <p className="text-red-500 text-sm mt-1">{errors.sex.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Location</label>
                <Input
                  {...register('location', { required: 'Location is required' })}
                  className={errors.location ? 'border-red-500' : ''}
                />
                {errors.location && (
                  <p className="text-red-500 text-sm mt-1">{errors.location.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Weight (kg)</label>
                <Input
                  type="number"
                  step="0.1"
                  {...register('weight', { 
                    required: 'Weight is required',
                    min: { value: 0, message: 'Weight must be positive' }
                  })}
                  className={errors.weight ? 'border-red-500' : ''}
                />
                {errors.weight && (
                  <p className="text-red-500 text-sm mt-1">{errors.weight.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Purchase Cost ($)</label>
                <Input
                  type="number"
                  step="0.01"
                  {...register('purchaseCost', { 
                    required: 'Purchase cost is required',
                    min: { value: 0, message: 'Cost must be positive' }
                  })}
                  className={errors.purchaseCost ? 'border-red-500' : ''}
                />
                {errors.purchaseCost && (
                  <p className="text-red-500 text-sm mt-1">{errors.purchaseCost.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Purchase Date</label>
                <Input
                  type="date"
                  {...register('purchaseDate', { required: 'Purchase date is required' })}
                  className={errors.purchaseDate ? 'border-red-500' : ''}
                />
                {errors.purchaseDate && (
                  <p className="text-red-500 text-sm mt-1">{errors.purchaseDate.message}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit">Add Stock</Button>
            </div>
          </form>
        </Card.Content>
      </Card>
    </div>
  );
}