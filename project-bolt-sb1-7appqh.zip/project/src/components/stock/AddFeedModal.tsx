import React from 'react';
import { useForm } from 'react-hook-form';
import { Card, Button, Input } from '../ui';
import { X } from 'lucide-react';
import { db } from '@/firebase.config';
import { collection, addDoc } from 'firebase/firestore';

interface AddFeedFormData {
  cvdNumber: string;
  description: string;
  storageMethod: string;
  purchaseDate: string;
  supplier: string;
  startFedDate: string;
  endFedDate?: string;
  fedToMobs: string;
  quantity: number;
  unit: string;
  cost: number;
}

interface AddFeedModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function AddFeedModal({ isOpen, onClose, onSuccess }: AddFeedModalProps) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<AddFeedFormData>();

  const onSubmit = async (data: AddFeedFormData) => {
    try {
      await addDoc(collection(db, 'feedRecords'), {
        ...data,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      reset();
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error adding feed record:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-2xl bg-white">
        <Card.Header className="flex justify-between items-center">
          <h3 className="text-lg font-medium">Add Feed Record</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </Card.Header>
        <Card.Content>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">CVD Number</label>
                <Input
                  {...register('cvdNumber', { required: 'CVD number is required' })}
                  className={errors.cvdNumber ? 'border-red-500' : ''}
                />
                {errors.cvdNumber && (
                  <p className="text-red-500 text-sm mt-1">{errors.cvdNumber.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Description</label>
                <Input
                  {...register('description', { required: 'Description is required' })}
                  className={errors.description ? 'border-red-500' : ''}
                />
                {errors.description && (
                  <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Storage Method</label>
                <Input
                  {...register('storageMethod', { required: 'Storage method is required' })}
                  className={errors.storageMethod ? 'border-red-500' : ''}
                />
                {errors.storageMethod && (
                  <p className="text-red-500 text-sm mt-1">{errors.storageMethod.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Purchase Date</label>
                <Input
                  type="date"
                  {...register('purchaseDate', { required: 'Purchase date is required' })}
                  className={errors.purchaseDate ? 'border-red-500' : ''}
                />
                {errors.purchaseDate && (
                  <p className="text-red-500 text-sm mt-1">{errors.purchaseDate.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Supplier</label>
                <Input
                  {...register('supplier', { required: 'Supplier is required' })}
                  className={errors.supplier ? 'border-red-500' : ''}
                />
                {errors.supplier && (
                  <p className="text-red-500 text-sm mt-1">{errors.supplier.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Start Fed Date</label>
                <Input
                  type="date"
                  {...register('startFedDate', { required: 'Start fed date is required' })}
                  className={errors.startFedDate ? 'border-red-500' : ''}
                />
                {errors.startFedDate && (
                  <p className="text-red-500 text-sm mt-1">{errors.startFedDate.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">End Fed Date</label>
                <Input
                  type="date"
                  {...register('endFedDate')}
                  className={errors.endFedDate ? 'border-red-500' : ''}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Fed To Mobs</label>
                <Input
                  {...register('fedToMobs', { required: 'Fed to mobs is required' })}
                  className={errors.fedToMobs ? 'border-red-500' : ''}
                />
                {errors.fedToMobs && (
                  <p className="text-red-500 text-sm mt-1">{errors.fedToMobs.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Quantity</label>
                <Input
                  type="number"
                  {...register('quantity', { 
                    required: 'Quantity is required',
                    min: { value: 0, message: 'Quantity must be positive' }
                  })}
                  className={errors.quantity ? 'border-red-500' : ''}
                />
                {errors.quantity && (
                  <p className="text-red-500 text-sm mt-1">{errors.quantity.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Unit</label>
                <select
                  {...register('unit', { required: 'Unit is required' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-coffee-400 focus:ring focus:ring-coffee-200"
                >
                  <option value="">Select unit</option>
                  <option value="kg">Kilograms (kg)</option>
                  <option value="ton">Tonnes</option>
                  <option value="bale">Bales</option>
                </select>
                {errors.unit && (
                  <p className="text-red-500 text-sm mt-1">{errors.unit.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Cost ($)</label>
                <Input
                  type="number"
                  step="0.01"
                  {...register('cost', { 
                    required: 'Cost is required',
                    min: { value: 0, message: 'Cost must be positive' }
                  })}
                  className={errors.cost ? 'border-red-500' : ''}
                />
                {errors.cost && (
                  <p className="text-red-500 text-sm mt-1">{errors.cost.message}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit">Add Feed Record</Button>
            </div>
          </form>
        </Card.Content>
      </Card>
    </div>
  );
}