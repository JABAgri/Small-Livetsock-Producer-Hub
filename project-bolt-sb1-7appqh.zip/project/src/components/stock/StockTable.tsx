import React, { useEffect, useState } from 'react';
import { Table, Button } from '../ui';
import { FileText, Syringe } from 'lucide-react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '@/firebase.config';

interface StockItem {
  id: string;
  visualTag: string;
  nlisId: string;
  type: string;
  breed: string;
  sex: string;
  status: string;
  location: string;
  weight: number;
  purchaseCost: number;
  salePrice?: number;
  updatedAt: string;
}

export default function StockTable() {
  const [stock, setStock] = useState<StockItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'stock'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const stockData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as StockItem[];
      
      setStock(stockData);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <Table>
      <Table.Header>
        <Table.Row>
          <Table.Head>Visual Tag</Table.Head>
          <Table.Head>NLIS ID</Table.Head>
          <Table.Head>Type</Table.Head>
          <Table.Head>Breed</Table.Head>
          <Table.Head>Sex</Table.Head>
          <Table.Head>Status</Table.Head>
          <Table.Head>Location</Table.Head>
          <Table.Head>Weight (kg)</Table.Head>
          <Table.Head>Purchase Cost</Table.Head>
          <Table.Head>Sale Price</Table.Head>
          <Table.Head>Last Updated</Table.Head>
          <Table.Head>Actions</Table.Head>
        </Table.Row>
      </Table.Header>
      <Table.Body>
        {stock.map((item) => (
          <Table.Row key={item.id}>
            <Table.Cell>{item.visualTag}</Table.Cell>
            <Table.Cell>{item.nlisId}</Table.Cell>
            <Table.Cell>{item.type}</Table.Cell>
            <Table.Cell>{item.breed}</Table.Cell>
            <Table.Cell>{item.sex}</Table.Cell>
            <Table.Cell>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                {item.status}
              </span>
            </Table.Cell>
            <Table.Cell>{item.location}</Table.Cell>
            <Table.Cell>{item.weight}</Table.Cell>
            <Table.Cell>${item.purchaseCost.toFixed(2)}</Table.Cell>
            <Table.Cell>{item.salePrice ? `$${item.salePrice.toFixed(2)}` : '-'}</Table.Cell>
            <Table.Cell>{new Date(item.updatedAt).toLocaleDateString()}</Table.Cell>
            <Table.Cell>
              <div className="flex space-x-2">
                <Button variant="ghost" size="sm">
                  <FileText className="h-4 w-4 mr-1" />
                  Details
                </Button>
                <Button variant="ghost" size="sm">
                  <Syringe className="h-4 w-4 mr-1" />
                  Vaccinations
                </Button>
              </div>
            </Table.Cell>
          </Table.Row>
        ))}
      </Table.Body>
    </Table>
  );
}