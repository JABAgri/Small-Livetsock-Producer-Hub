import React from 'react';
import { Card } from '../ui';

interface StockCategoryProps {
  image: string;
  title: string;
  count: number;
}

const StockCategory = ({ image, title, count }: StockCategoryProps) => (
  <Card className="bg-cream-50">
    <Card.Content className="p-4">
      <img 
        src={image}
        alt={title}
        className="w-full h-40 object-cover rounded-lg mb-4"
      />
      <h3 className="text-lg font-medium mb-2">{title}</h3>
      <p className="text-sm text-gray-600">Total Count: {count}</p>
    </Card.Content>
  </Card>
);

export default function StockOverview() {
  const categories = [
    {
      image: "https://images.unsplash.com/photo-1484557985045-edf25e08da73",
      title: "Sheep",
      count: 150
    },
    {
      image: "https://images.unsplash.com/photo-1527153857715-3908f2bae5e8",
      title: "Cattle",
      count: 75
    },
    {
      image: "https://images.unsplash.com/photo-1560926036-3d2d5ec80f08",
      title: "Goats",
      count: 20
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      {categories.map((category) => (
        <StockCategory key={category.title} {...category} />
      ))}
    </div>
  );
}