import React, { useState, useEffect } from 'react';
import { Card, Table, Button } from '../ui';
import { Plus, FileText } from 'lucide-react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '@/firebase.config';
import AddFeedModal from './AddFeedModal';

interface FeedRecord {
  id: string;
  cvdNumber: string;
  description: string;
  storageMethod: string;
  purchaseDate: string;
  supplier: string;
  startFedDate: string;
  endFedDate?: string;
  fedToMobs: string;
  quantity: number;
  unit: string;
  cost: number;
}

export default function FeedRegister() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [feedRecords, setFeedRecords] = useState<FeedRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'feedRecords'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const records = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as FeedRecord[];
      
      setFeedRecords(records);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAddSuccess = () => {
    // Refresh will happen automatically due to the snapshot listener
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <Card>
      <Card.Header>
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium">Feed Register</h3>
          <Button onClick={() => setIsAddModalOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Feed Record
          </Button>
        </div>
      </Card.Header>
      <Card.Content>
        <Table>
          <Table.Header>
            <Table.Row>
              <Table.Head>CVD Number</Table.Head>
              <Table.Head>Feed Description</Table.Head>
              <Table.Head>Storage Method</Table.Head>
              <Table.Head>Purchase Date</Table.Head>
              <Table.Head>Supplier</Table.Head>
              <Table.Head>Start Fed Date</Table.Head>
              <Table.Head>End Fed Date</Table.Head>
              <Table.Head>Fed To Mobs</Table.Head>
              <Table.Head>Actions</Table.Head>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {feedRecords.map((record) => (
              <Table.Row key={record.id}>
                <Table.Cell>{record.cvdNumber}</Table.Cell>
                <Table.Cell>{record.description}</Table.Cell>
                <Table.Cell>{record.storageMethod}</Table.Cell>
                <Table.Cell>{record.purchaseDate}</Table.Cell>
                <Table.Cell>{record.supplier}</Table.Cell>
                <Table.Cell>{record.startFedDate}</Table.Cell>
                <Table.Cell>{record.endFedDate || 'Ongoing'}</Table.Cell>
                <Table.Cell>{record.fedToMobs}</Table.Cell>
                <Table.Cell>
                  <Button variant="ghost" size="sm">
                    <FileText className="h-4 w-4 mr-1" />
                    Details
                  </Button>
                </Table.Cell>
              </Table.Row>
            ))}
          </Table.Body>
        </Table>
      </Card.Content>

      <AddFeedModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSuccess={handleAddSuccess}
      />
    </Card>
  );
}