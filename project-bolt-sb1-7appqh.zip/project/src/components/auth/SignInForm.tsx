import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Card, Button, Input } from '../ui';
import { useAuth } from '@/lib/auth/AuthContext';
import { useNavigate } from 'react-router-dom';

interface SignInFormData {
  email: string;
  password: string;
}

export default function SignInForm() {
  const { register, handleSubmit, formState: { errors }, setError: setFormError } = useForm<SignInFormData>();
  const { signIn, error: authError, clearError } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (authError) {
      setFormError('root', { message: authError });
    }
    return () => clearError();
  }, [authError, setFormError, clearError]);

  const onSubmit = async (data: SignInFormData) => {
    try {
      await signIn(data.email, data.password);
      navigate('/dashboard');
    } catch (error) {
      // Error is handled by the useEffect above
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-cream-50">
      <Card className="w-full max-w-md">
        <Card.Header>
          <h2 className="text-2xl font-semibold text-center">Sign In</h2>
        </Card.Header>
        <Card.Content>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            {errors.root && (
              <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                {errors.root.message}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700">Email</label>
              <Input
                type="email"
                {...register('email', { required: 'Email is required' })}
                className={errors.email ? 'border-red-500' : ''}
              />
              {errors.email && (
                <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Password</label>
              <Input
                type="password"
                {...register('password', { required: 'Password is required' })}
                className={errors.password ? 'border-red-500' : ''}
              />
              {errors.password && (
                <p className="text-red-500 text-sm mt-1">{errors.password.message}</p>
              )}
            </div>

            <Button type="submit" className="w-full">
              Sign In
            </Button>

            <p className="text-center text-sm text-gray-600">
              Don't have an account?{' '}
              <a href="/signup" className="text-coffee-400 hover:text-coffee-500">
                Sign up
              </a>
            </p>
          </form>
        </Card.Content>
      </Card>
    </div>
  );
}