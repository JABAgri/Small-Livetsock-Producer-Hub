import React, { useState, useEffect } from 'react';
import { Card, Button } from './ui';
import { QRCodeSVG } from 'qrcode.react';
import { Smartphone, Upload, FileText, Download } from 'lucide-react';
import { useDropzone } from 'react-dropzone';

export default function DocumentTray() {
  const [documents, setDocuments] = useState([
    { id: 1, name: 'NVD_12345.pdf', uploadTime: '2 hours ago' },
    { id: 2, name: 'Treatment_Record_Feb2024.pdf', uploadTime: 'yesterday' }
  ]);

  const [connectionCode, setConnectionCode] = useState('');

  useEffect(() => {
    // Generate a unique connection code
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    setConnectionCode(code);
  }, []);

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.png', '.jpg', '.jpeg']
    },
    onDrop: (acceptedFiles) => {
      const newDocs = acceptedFiles.map((file, index) => ({
        id: documents.length + index + 1,
        name: file.name,
        uploadTime: 'just now'
      }));
      setDocuments([...newDocs, ...documents]);
    }
  });

  const appLink = {
    android: 'https://play.google.com/store/apps/details?id=com.jabagri.livestockhub',
    ios: 'https://apps.apple.com/app/livestock-hub/id123456789',
    deepLink: `livestockhub://connect?code=${connectionCode}&origin=${window.location.origin}`
  };
  
  const handleAppStoreClick = (platform: 'ios' | 'android') => {
    window.open(appLink[platform], '_blank');
  };

  const handleDownload = (documentName: string) => {
    console.log(`Downloading ${documentName}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-gray-900">Document Tray</h2>
        <Button>
          <Upload className="h-4 w-4 mr-2" />
          Upload Document
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <Smartphone className="h-6 w-6 text-blue-500" />
              <h3 className="text-lg font-medium">Mobile App Connection</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <div className="flex justify-center">
                <QRCodeSVG value={appLink.deepLink} size={180} />
              </div>
              <div className="text-center">
                <p className="text-lg font-semibold text-gray-900">Connection Code:</p>
                <p className="text-2xl font-bold text-coffee-400 tracking-wider">{connectionCode}</p>
              </div>
              <p className="text-sm text-center text-gray-600">
                Scan this QR code or enter the connection code in your mobile app to sync
              </p>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => handleAppStoreClick('ios')}
                >
                  App Store
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => handleAppStoreClick('android')}
                >
                  Play Store
                </Button>
              </div>
            </div>
          </Card.Content>
        </Card>

        <Card className="md:col-span-2">
          <Card.Header>
            <h3 className="text-lg font-medium">Upload Documents</h3>
          </Card.Header>
          <Card.Content>
            <div {...getRootProps()} className="border-2 border-dashed border-gray-300 rounded-lg p-6 cursor-pointer hover:border-blue-500 transition-colors">
              <input {...getInputProps()} />
              <div className="text-center space-y-2">
                <Upload className="h-12 w-12 text-gray-400 mx-auto" />
                <p className="text-gray-600">Drag and drop files here, or click to select files</p>
                <p className="text-sm text-gray-500">Supports PDF, PNG, JPG (up to 10MB)</p>
              </div>
            </div>
          </Card.Content>
        </Card>
      </div>

      <Card>
        <Card.Header>
          <h3 className="text-lg font-medium">Recent Documents</h3>
        </Card.Header>
        <Card.Content>
          <div className="space-y-4">
            {documents.map((doc) => (
              <div key={doc.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <FileText className="h-6 w-6 text-blue-500" />
                  <div>
                    <p className="font-medium">{doc.name}</p>
                    <p className="text-sm text-gray-500">Uploaded {doc.uploadTime}</p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleDownload(doc.name)}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>
            ))}
          </div>
        </Card.Content>
      </Card>
    </div>
  );
}