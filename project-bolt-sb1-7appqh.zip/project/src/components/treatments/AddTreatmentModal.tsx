import React from 'react';
import { useForm } from 'react-hook-form';
import { Card, Button, Input } from '../ui';
import { X } from 'lucide-react';
import { db } from '@/firebase.config';
import { collection, addDoc } from 'firebase/firestore';

interface AddTreatmentFormData {
  type: string;
  product: string;
  batchNumber: string;
  dosage: string;
  dateAdministered: string;
  whpStart: string;
  whpEnd: string;
  operator: string;
  notes: string;
}

interface AddTreatmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function AddTreatmentModal({ isOpen, onClose, onSuccess }: AddTreatmentModalProps) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<AddTreatmentFormData>();

  const onSubmit = async (data: AddTreatmentFormData) => {
    try {
      await addDoc(collection(db, 'treatments'), {
        ...data,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      reset();
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error adding treatment:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-2xl bg-white">
        <Card.Header className="flex justify-between items-center">
          <h3 className="text-lg font-medium">Add Treatment Record</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </Card.Header>
        <Card.Content>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Treatment Type</label>
                <select
                  {...register('type', { required: 'Treatment type is required' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-coffee-400 focus:ring focus:ring-coffee-200"
                >
                  <option value="">Select type</option>
                  <option value="Vaccination">Vaccination</option>
                  <option value="Drench">Drench</option>
                  <option value="Pour-on">Pour-on</option>
                  <option value="Injection">Injection</option>
                </select>
                {errors.type && (
                  <p className="text-red-500 text-sm mt-1">{errors.type.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Product</label>
                <Input
                  {...register('product', { required: 'Product is required' })}
                  className={errors.product ? 'border-red-500' : ''}
                />
                {errors.product && (
                  <p className="text-red-500 text-sm mt-1">{errors.product.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Batch Number</label>
                <Input
                  {...register('batchNumber', { required: 'Batch number is required' })}
                  className={errors.batchNumber ? 'border-red-500' : ''}
                />
                {errors.batchNumber && (
                  <p className="text-red-500 text-sm mt-1">{errors.batchNumber.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Dosage</label>
                <Input
                  {...register('dosage', { required: 'Dosage is required' })}
                  className={errors.dosage ? 'border-red-500' : ''}
                />
                {errors.dosage && (
                  <p className="text-red-500 text-sm mt-1">{errors.dosage.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Date Administered</label>
                <Input
                  type="date"
                  {...register('dateAdministered', { required: 'Date is required' })}
                  className={errors.dateAdministered ? 'border-red-500' : ''}
                />
                {errors.dateAdministered && (
                  <p className="text-red-500 text-sm mt-1">{errors.dateAdministered.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">WHP Start</label>
                <Input
                  type="date"
                  {...register('whpStart', { required: 'WHP start date is required' })}
                  className={errors.whpStart ? 'border-red-500' : ''}
                />
                {errors.whpStart && (
                  <p className="text-red-500 text-sm mt-1">{errors.whpStart.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">WHP End</label>
                <Input
                  type="date"
                  {...register('whpEnd', { required: 'WHP end date is required' })}
                  className={errors.whpEnd ? 'border-red-500' : ''}
                />
                {errors.whpEnd && (
                  <p className="text-red-500 text-sm mt-1">{errors.whpEnd.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Operator</label>
                <Input
                  {...register('operator', { required: 'Operator is required' })}
                  className={errors.operator ? 'border-red-500' : ''}
                />
                {errors.operator && (
                  <p className="text-red-500 text-sm mt-1">{errors.operator.message}</p>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Notes</label>
              <textarea
                {...register('notes')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-coffee-400 focus:ring focus:ring-coffee-200"
                rows={3}
              />
            </div>

            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit">Add Treatment</Button>
            </div>
          </form>
        </Card.Content>
      </Card>
    </div>
  );
}