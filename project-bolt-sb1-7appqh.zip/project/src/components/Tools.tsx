import React from 'react';
import { Card, Button, Input } from './ui';
import { Calculator, Calendar, Scale, Thermometer } from 'lucide-react';

export default function Tools() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-gray-900">Producer Tools</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <Calculator className="h-6 w-6 text-blue-500" />
              <h3 className="text-lg font-medium">Feed Calculator</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Number of Animals</label>
                <Input type="number" placeholder="Enter count" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Average Weight (kg)</label>
                <Input type="number" placeholder="Enter weight" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Feed Type</label>
                <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                  <option>Hay</option>
                  <option>Grain</option>
                  <option>Silage</option>
                </select>
              </div>
              <Button className="w-full">Calculate Requirements</Button>
            </div>
          </Card.Content>
        </Card>

        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <Calendar className="h-6 w-6 text-green-500" />
              <h3 className="text-lg font-medium">Treatment Scheduler</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Treatment Type</label>
                <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                  <option>Vaccination</option>
                  <option>Drenching</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Start Date</label>
                <Input type="date" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Repeat Interval</label>
                <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                  <option>One-time</option>
                  <option>Monthly</option>
                  <option>Quarterly</option>
                  <option>Annually</option>
                </select>
              </div>
              <Button className="w-full">Schedule Treatment</Button>
            </div>
          </Card.Content>
        </Card>

        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <Scale className="h-6 w-6 text-orange-500" />
              <h3 className="text-lg font-medium">Weight Tracker</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <div className="flex space-x-4">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700">Initial Weight</label>
                  <Input type="number" placeholder="kg" />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700">Current Weight</label>
                  <Input type="number" placeholder="kg" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Time Period</label>
                <Input type="number" placeholder="Days" />
              </div>
              <Button className="w-full">Calculate Growth Rate</Button>
            </div>
          </Card.Content>
        </Card>

        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <Thermometer className="h-6 w-6 text-red-500" />
              <h3 className="text-lg font-medium">Weather Monitor</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Location</label>
                <Input placeholder="Enter property location" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-700">Temperature</p>
                  <p className="text-2xl font-bold">24°C</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Rainfall</p>
                  <p className="text-2xl font-bold">2.5mm</p>
                </div>
              </div>
              <Button variant="outline" className="w-full">View Forecast</Button>
            </div>
          </Card.Content>
        </Card>
      </div>
    </div>
  );
}