import React from 'react';
import { Card, Button, Table } from './ui';
import { Shield, AlertTriangle, CheckCircle, Plus } from 'lucide-react';

export default function BiosecurityPlan() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-gray-900">Biosecurity Management</h2>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Risk Assessment
        </Button>
      </div>

      <Card>
        <Card.Header>
          <div className="flex items-center space-x-4">
            <Shield className="h-6 w-6 text-blue-500" />
            <h3 className="text-lg font-medium">Biosecurity Plan Status</h3>
          </div>
        </Card.Header>
        <Card.Content>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-500" />
                <span className="font-medium">Plan Status: Active</span>
              </div>
              <p className="text-sm text-gray-600 mt-2">Last reviewed: 01/01/2024</p>
            </div>
            <div className="p-4 bg-yellow-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-yellow-500" />
                <span className="font-medium">Next Review Due</span>
              </div>
              <p className="text-sm text-gray-600 mt-2">Due date: 01/07/2024</p>
            </div>
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-blue-500" />
                <span className="font-medium">Risk Level</span>
              </div>
              <p className="text-sm text-gray-600 mt-2">Current: Moderate</p>
            </div>
          </div>
        </Card.Content>
      </Card>

      <Card>
        <Card.Header>
          <h3 className="text-lg font-medium">Risk Assessment Register</h3>
        </Card.Header>
        <Card.Content>
          <Table>
            <Table.Header>
              <Table.Row>
                <Table.Head>Risk Area</Table.Head>
                <Table.Head>Identified Risks</Table.Head>
                <Table.Head>Control Measures</Table.Head>
                <Table.Head>Risk Level</Table.Head>
                <Table.Head>Review Date</Table.Head>
                <Table.Head>Status</Table.Head>
                <Table.Head>Actions</Table.Head>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              <Table.Row>
                <Table.Cell>Animal Movement</Table.Cell>
                <Table.Cell>Disease transmission</Table.Cell>
                <Table.Cell>Quarantine procedures</Table.Cell>
                <Table.Cell>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                    Medium
                  </span>
                </Table.Cell>
                <Table.Cell>01/03/2024</Table.Cell>
                <Table.Cell>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Active
                  </span>
                </Table.Cell>
                <Table.Cell>
                  <Button variant="ghost" size="sm">Update</Button>
                </Table.Cell>
              </Table.Row>
              <Table.Row>
                <Table.Cell>Feed Storage</Table.Cell>
                <Table.Cell>Contamination</Table.Cell>
                <Table.Cell>Secure storage facilities</Table.Cell>
                <Table.Cell>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                    High
                  </span>
                </Table.Cell>
                <Table.Cell>15/03/2024</Table.Cell>
                <Table.Cell>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                    Review Required
                  </span>
                </Table.Cell>
                <Table.Cell>
                  <Button variant="ghost" size="sm">Update</Button>
                </Table.Cell>
              </Table.Row>
            </Table.Body>
          </Table>
        </Card.Content>
      </Card>

      <Card>
        <Card.Header>
          <h3 className="text-lg font-medium">Visitor Register</h3>
        </Card.Header>
        <Card.Content>
          <Table>
            <Table.Header>
              <Table.Row>
                <Table.Head>Date</Table.Head>
                <Table.Head>Visitor Name</Table.Head>
                <Table.Head>Company</Table.Head>
                <Table.Head>Purpose</Table.Head>
                <Table.Head>Areas Accessed</Table.Head>
                <Table.Head>Risk Level</Table.Head>
                <Table.Head>Actions</Table.Head>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              <Table.Row>
                <Table.Cell>01/02/2024</Table.Cell>
                <Table.Cell>John Smith</Table.Cell>
                <Table.Cell>Vet Services</Table.Cell>
                <Table.Cell>Animal Health Check</Table.Cell>
                <Table.Cell>Paddock A, B</Table.Cell>
                <Table.Cell>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                    Medium
                  </span>
                </Table.Cell>
                <Table.Cell>
                  <Button variant="ghost" size="sm">View Details</Button>
                </Table.Cell>
              </Table.Row>
            </Table.Body>
          </Table>
        </Card.Content>
      </Card>
    </div>
  );
}