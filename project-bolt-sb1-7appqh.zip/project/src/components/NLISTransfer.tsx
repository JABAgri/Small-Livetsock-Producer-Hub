import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Input } from './ui';
import { Upload, ArrowRight, Plus, FileText } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '@/firebase.config';
import { format } from 'date-fns';
import { showSuccess, showError } from '@/lib/utils/toast';

interface NLISTransfer {
  id: string;
  nvdNumber: string;
  fromPIC: string;
  toPIC: string;
  date: string;
  numberOfHead: number;
  status: string;
  transportDetails: string;
}

export default function NLISTransfer() {
  const [transfers, setTransfers] = useState<NLISTransfer[]>([]);
  const [loading, setLoading] = useState(true);

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'application/pdf': ['.pdf']
    },
    onDrop: (acceptedFiles) => {
      handleFileUpload(acceptedFiles);
    }
  });

  useEffect(() => {
    const q = query(collection(db, 'nlisTransfers'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const transferData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as NLISTransfer[];
      
      setTransfers(transferData);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleFileUpload = async (files: File[]) => {
    try {
      // Handle file upload logic here
      showSuccess('File uploaded successfully');
    } catch (error) {
      console.error('Error uploading file:', error);
      showError('Failed to upload file');
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="relative">
        <img 
          src="https://images.unsplash.com/photo-1527153857715-3908f2bae5e8"
          alt="Cattle transport"
          className="w-full h-48 object-cover rounded-lg"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent flex items-center">
          <h2 className="text-2xl font-semibold text-white px-6">NLIS Data Transfer</h2>
        </div>
      </div>

      <Card>
        <Card.Header>
          <h3 className="text-lg font-medium">New Transfer</h3>
        </Card.Header>
        <Card.Content>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">NVD/Waybill Number</label>
                <Input placeholder="Enter NVD number" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">From PIC</label>
                <Input placeholder="Enter PIC number" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">To PIC</label>
                <Input placeholder="Enter PIC number" />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700">Upload NVD</label>
              <div {...getRootProps()} className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer hover:border-coffee-400">
                <div className="space-y-1 text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="flex text-sm text-gray-600">
                    <label className="relative cursor-pointer rounded-md font-medium text-coffee-400 hover:text-coffee-500">
                      <span>Upload a file</span>
                      <input {...getInputProps()} />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-gray-500">PDF up to 10MB</p>
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <Button>
                Transfer Data
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card.Content>
      </Card>

      <Card>
        <Card.Header>
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Transfer History</h3>
            <Button variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Bulk Upload
            </Button>
          </div>
        </Card.Header>
        <Card.Content>
          <Table>
            <Table.Header>
              <Table.Row>
                <Table.Head>NVD Number</Table.Head>
                <Table.Head>From PIC</Table.Head>
                <Table.Head>To PIC</Table.Head>
                <Table.Head>Date</Table.Head>
                <Table.Head>Number of Head</Table.Head>
                <Table.Head>Status</Table.Head>
                <Table.Head>Actions</Table.Head>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              {transfers.map((transfer) => (
                <Table.Row key={transfer.id}>
                  <Table.Cell>{transfer.nvdNumber}</Table.Cell>
                  <Table.Cell>{transfer.fromPIC}</Table.Cell>
                  <Table.Cell>{transfer.toPIC}</Table.Cell>
                  <Table.Cell>{format(new Date(transfer.date), 'dd/MM/yyyy')}</Table.Cell>
                  <Table.Cell>{transfer.numberOfHead}</Table.Cell>
                  <Table.Cell>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      transfer.status === 'Completed' 
                        ? 'bg-green-100 text-green-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {transfer.status}
                    </span>
                  </Table.Cell>
                  <Table.Cell>
                    <Button variant="ghost" size="sm">
                      <FileText className="h-4 w-4 mr-2" />
                      View NVD
                    </Button>
                  </Table.Cell>
                </Table.Row>
              ))}
            </Table.Body>
          </Table>
        </Card.Content>
      </Card>
    </div>
  );
}