import React from 'react';
import { Card, Button, Input } from './ui';
import { Plus, Filter, Wheat } from 'lucide-react';
import StockOverview from './stock/StockOverview';
import StockTable from './stock/StockTable';
import FeedRegister from './stock/FeedRegister';

export default function StockManagement() {
  return (
    <div className="space-y-6">
      <div className="relative">
        <img 
          src="https://images.unsplash.com/photo-1484557985045-edf25e08da73"
          alt="Sheep grazing"
          className="w-full h-48 object-cover rounded-lg"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent flex items-center">
          <h2 className="text-2xl font-semibold text-white px-6">Stock Management</h2>
        </div>
      </div>

      <div className="flex justify-end space-x-2">
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add New Stock
        </Button>
        <Button variant="outline">
          <Wheat className="h-4 w-4 mr-2" />
          Feed Register
        </Button>
      </div>

      <StockOverview />

      <Card>
        <Card.Header>
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Current Stock</h3>
            <div className="flex space-x-2">
              <Input 
                placeholder="Search..." 
                className="w-64"
              />
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </Card.Header>
        <Card.Content>
          <StockTable />
        </Card.Content>
      </Card>

      <FeedRegister />
    </div>
  );
}