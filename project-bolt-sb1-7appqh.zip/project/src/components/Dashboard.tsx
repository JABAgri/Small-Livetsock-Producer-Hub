import React, { useEffect, useRef, useState } from 'react';
import { Card, Button } from './ui';
import { AlertTriangle, CheckCircle, Clock, Activity } from 'lucide-react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { MAPBOX_TOKEN, DEFAULT_CENTER, DEFAULT_ZOOM, isMapboxConfigured } from '@/config/mapbox';
import { MapPlaceholder } from './ui/map-placeholder';
import { useNavigate } from 'react-router-dom';
import AddStockModal from './stock/AddStockModal';
import AddTreatmentModal from './treatments/AddTreatmentModal';
import NLISTransferModal from './nlis/NLISTransferModal';

mapboxgl.accessToken = MAPBOX_TOKEN;

export default function Dashboard() {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const navigate = useNavigate();
  
  const [isAddStockModalOpen, setIsAddStockModalOpen] = useState(false);
  const [isAddTreatmentModalOpen, setIsAddTreatmentModalOpen] = useState(false);
  const [isNLISModalOpen, setIsNLISModalOpen] = useState(false);

  useEffect(() => {
    if (!isMapboxConfigured || !mapContainer.current || map.current) return;

    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/satellite-v9',
        center: DEFAULT_CENTER,
        zoom: DEFAULT_ZOOM,
        interactive: true
      });

      map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');
      
      new mapboxgl.Marker()
        .setLngLat(DEFAULT_CENTER)
        .addTo(map.current);

    } catch (error) {
      console.error('Error initializing map:', error);
    }

    return () => {
      map.current?.remove();
    };
  }, []);

  const handleRecordMovement = () => {
    setIsAddStockModalOpen(true);
  };

  const handleAddTreatment = () => {
    setIsAddTreatmentModalOpen(true);
  };

  const handleUpdateNLIS = () => {
    setIsNLISModalOpen(true);
  };

  const handleViewReports = () => {
    navigate('/reports');
  };

  return (
    <div className="space-y-6">
      <div className="relative">
        <img 
          src="https://images.unsplash.com/photo-1527153857715-3908f2bae5e8"
          alt="Cattle grazing"
          className="w-full h-48 object-cover rounded-lg"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent flex items-center">
          <h2 className="text-2xl font-semibold text-white px-6">Dashboard Overview</h2>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-cream-50">
          <Card.Content className="p-4">
            <Clock className="h-8 w-8 text-coffee-400" />
            <div className="mt-2">
              <p className="text-2xl font-bold text-gray-900">5</p>
              <p className="text-sm text-gray-900">Tasks Due</p>
            </div>
          </Card.Content>
        </Card>

        <Card className="bg-cream-50">
          <Card.Content className="p-4">
            <AlertTriangle className="h-8 w-8 text-coffee-400" />
            <div className="mt-2">
              <p className="text-2xl font-bold text-gray-900">2</p>
              <p className="text-sm text-gray-900">Alerts</p>
            </div>
          </Card.Content>
        </Card>

        <Card className="bg-cream-50">
          <Card.Content className="p-4">
            <CheckCircle className="h-8 w-8 text-coffee-400" />
            <div className="mt-2">
              <p className="text-2xl font-bold text-gray-900">98%</p>
              <p className="text-sm text-gray-900">Compliance</p>
            </div>
          </Card.Content>
        </Card>

        <Card className="bg-cream-50">
          <Card.Content className="p-4">
            <Activity className="h-8 w-8 text-coffee-400" />
            <div className="mt-2">
              <p className="text-2xl font-bold text-gray-900">245</p>
              <p className="text-sm text-gray-900">Stock Count</p>
            </div>
          </Card.Content>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-cream-50">
          <Card.Header>
            <h3 className="text-lg font-medium">Property Map</h3>
          </Card.Header>
          <Card.Content>
            {isMapboxConfigured ? (
              <div ref={mapContainer} className="h-[400px] rounded-lg overflow-hidden" />
            ) : (
              <MapPlaceholder />
            )}
          </Card.Content>
        </Card>

        <Card className="bg-cream-50">
          <Card.Header>
            <h3 className="text-lg font-medium">Quick Actions</h3>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={handleRecordMovement}
              >
                Record Movement
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={handleAddTreatment}
              >
                Add Treatment
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={handleUpdateNLIS}
              >
                Update NLIS
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={handleViewReports}
              >
                View Reports
              </Button>
            </div>
          </Card.Content>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-cream-50">
          <Card.Header>
            <h3 className="text-lg font-medium">Recent Activity</h3>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <img 
                  src="https://images.unsplash.com/photo-1484557985045-edf25e08da73"
                  alt="Sheep"
                  className="h-12 w-12 rounded-full object-cover"
                />
                <div>
                  <p className="text-sm font-medium text-gray-900">NLIS Transfer Completed</p>
                  <p className="text-xs text-gray-900">2 hours ago</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <img 
                  src="https://images.unsplash.com/photo-1560926036-3d2d5ec80f08"
                  alt="Goats"
                  className="h-12 w-12 rounded-full object-cover"
                />
                <div>
                  <p className="text-sm font-medium text-gray-900">Vaccination Records Updated</p>
                  <p className="text-xs text-gray-900">Yesterday</p>
                </div>
              </div>
            </div>
          </Card.Content>
        </Card>

        <Card className="bg-cream-50">
          <Card.Header>
            <h3 className="text-lg font-medium">Weather Forecast</h3>
          </Card.Header>
          <Card.Content>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1527153857715-3908f2bae5e8"
                alt="Cattle grazing"
                className="w-full h-48 rounded-lg object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-4">
                <div className="text-white">
                  <p className="text-2xl font-bold">24°C</p>
                  <p className="text-sm">Partly Cloudy</p>
                  <p className="text-xs">Precipitation: 20%</p>
                </div>
              </div>
            </div>
          </Card.Content>
        </Card>
      </div>

      <AddStockModal
        isOpen={isAddStockModalOpen}
        onClose={() => setIsAddStockModalOpen(false)}
        onSuccess={() => setIsAddStockModalOpen(false)}
      />

      <AddTreatmentModal
        isOpen={isAddTreatmentModalOpen}
        onClose={() => setIsAddTreatmentModalOpen(false)}
        onSuccess={() => setIsAddTreatmentModalOpen(false)}
      />

      <NLISTransferModal
        isOpen={isNLISModalOpen}
        onClose={() => setIsNLISModalOpen(false)}
        onSuccess={() => setIsNLISModalOpen(false)}
      />
    </div>
  );
}