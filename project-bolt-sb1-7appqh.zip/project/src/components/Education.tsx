import React from 'react';
import { Card, Button } from './ui';
import { BookOpen, Video, Award, ExternalLink } from 'lucide-react';

export default function Education() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-gray-900">Education & Training</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <Award className="h-6 w-6 text-blue-500" />
              <h3 className="text-lg font-medium">LPA Certification</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <p className="text-sm text-gray-600 mb-4">Complete your LPA certification and stay compliant with industry standards.</p>
            <Button className="w-full">
              Start Course
              <ExternalLink className="h-4 w-4 ml-2" />
            </Button>
          </Card.Content>
        </Card>

        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <Video className="h-6 w-6 text-green-500" />
              <h3 className="text-lg font-medium">Video Tutorials</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <p className="text-sm text-gray-600 mb-4">Watch step-by-step guides on NLIS transfers, stock management, and more.</p>
            <Button variant="outline" className="w-full">
              View Library
            </Button>
          </Card.Content>
        </Card>

        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <BookOpen className="h-6 w-6 text-purple-500" />
              <h3 className="text-lg font-medium">Best Practices</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <p className="text-sm text-gray-600 mb-4">Learn industry best practices for livestock management and compliance.</p>
            <Button variant="outline" className="w-full">
              Browse Guides
            </Button>
          </Card.Content>
        </Card>
      </div>

      <Card>
        <Card.Header>
          <h3 className="text-lg font-medium">Upcoming Webinars</h3>
        </Card.Header>
        <Card.Content>
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b pb-4">
              <div>
                <h4 className="font-medium">NLIS Compliance Update 2024</h4>
                <p className="text-sm text-gray-500">February 15, 2024 - 2:00 PM</p>
              </div>
              <Button size="sm">Register</Button>
            </div>
            <div className="flex items-center justify-between border-b pb-4">
              <div>
                <h4 className="font-medium">Sustainable Farming Practices</h4>
                <p className="text-sm text-gray-500">March 1, 2024 - 10:00 AM</p>
              </div>
              <Button size="sm">Register</Button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Digital Record Keeping Workshop</h4>
                <p className="text-sm text-gray-500">March 15, 2024 - 1:00 PM</p>
              </div>
              <Button size="sm">Register</Button>
            </div>
          </div>
        </Card.Content>
      </Card>
    </div>
  );
}