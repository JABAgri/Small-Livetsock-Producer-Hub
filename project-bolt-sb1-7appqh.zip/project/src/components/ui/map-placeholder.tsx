import React from 'react';
import { MapPin } from 'lucide-react';

export function MapPlaceholder() {
  return (
    <div className="h-[400px] w-full bg-gray-100 rounded-lg flex items-center justify-center">
      <div className="text-center">
        <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-2" />
        <p className="text-gray-500">Map preview unavailable</p>
        <p className="text-sm text-gray-400">Configure Mapbox token to enable mapping features</p>
      </div>
    </div>
  );
}