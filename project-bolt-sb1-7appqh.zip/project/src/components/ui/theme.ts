import { DefaultTheme } from 'react-native-paper';

export const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#CCAF9B',
    background: '#FAF6ED',
    surface: '#FFFFFF',
    accent: '#D6BFAF',
    text: '#333333',
    placeholder: '#666666',
    border: '#E6DCCA',
  },
  roundness: 8,
};