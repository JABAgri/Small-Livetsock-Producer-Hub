import { cn } from "@/lib/utils";
import React from "react";

interface MenuItemProps extends React.HTMLAttributes<HTMLDivElement> {
  icon?: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
}

const MenuItem = React.forwardRef<HTMLDivElement, MenuItemProps>(
  ({ className, children, icon, active, onClick, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          "flex items-center px-4 py-2 text-sm cursor-pointer transition-colors",
          active
            ? "bg-cream-100 text-gray-900 font-medium"
            : "text-gray-900 hover:bg-cream-50",
          className
        )}
        onClick={onClick}
        {...props}
      >
        {icon && <span className="mr-3 h-5 w-5 text-coffee-400">{icon}</span>}
        {children}
      </div>
    );
  }
);
MenuItem.displayName = "MenuItem";

interface MenuProps extends React.HTMLAttributes<HTMLDivElement> {}

const Menu = React.forwardRef<HTMLDivElement, MenuProps>(({ className, ...props }, ref) => (
  <nav
    ref={ref}
    className={cn("py-2 space-y-1", className)}
    {...props}
  />
));
Menu.displayName = "Menu";

Menu.Item = MenuItem;

export { Menu, MenuItem };