import React from 'react';
import { Card, Button } from './ui';
import { FileText, Download, Link2, Phone, ExternalLink } from 'lucide-react';

export default function Resources() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-gray-900">Resources</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <FileText className="h-6 w-6 text-blue-500" />
              <h3 className="text-lg font-medium">Documentation</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm">NLIS User Guide</span>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">LPA Requirements</span>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Record Templates</span>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card.Content>
        </Card>

        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <Link2 className="h-6 w-6 text-green-500" />
              <h3 className="text-lg font-medium">Quick Links</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <Button variant="outline" className="w-full justify-between">
                NLIS Database
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between">
                MLA Website
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between">
                ISC Portal
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
          </Card.Content>
        </Card>

        <Card>
          <Card.Header>
            <div className="flex items-center space-x-4">
              <Phone className="h-6 w-6 text-purple-500" />
              <h3 className="text-lg font-medium">Support Contacts</h3>
            </div>
          </Card.Header>
          <Card.Content>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium">NLIS Support</h4>
                <p className="text-sm text-gray-500">1800 654 743</p>
                <p className="text-sm text-gray-500">support@nlis.com.au</p>
              </div>
              <div>
                <h4 className="font-medium">LPA Support</h4>
                <p className="text-sm text-gray-500">1800 683 111</p>
                <p className="text-sm text-gray-500">lpa@mla.com.au</p>
              </div>
              <div>
                <h4 className="font-medium">Technical Support</h4>
                <p className="text-sm text-gray-500">1800 123 456</p>
                <p className="text-sm text-gray-500">help@hub.com.au</p>
              </div>
            </div>
          </Card.Content>
        </Card>
      </div>

      <Card>
        <Card.Header>
          <h3 className="text-lg font-medium">Latest Industry Updates</h3>
        </Card.Header>
        <Card.Content>
          <div className="space-y-4">
            <div className="border-b pb-4">
              <h4 className="font-medium">Updated NLIS Requirements for 2024</h4>
              <p className="text-sm text-gray-600 mt-1">New regulations coming into effect from March 2024. Read the full update to ensure compliance.</p>
              <Button variant="ghost" size="sm" className="mt-2">
                Read More
                <ExternalLink className="h-4 w-4 ml-2" />
              </Button>
            </div>
            <div className="border-b pb-4">
              <h4 className="font-medium">MLA Market Report - January 2024</h4>
              <p className="text-sm text-gray-600 mt-1">Latest market trends and price forecasts for small livestock producers.</p>
              <Button variant="ghost" size="sm" className="mt-2">
                Read More
                <ExternalLink className="h-4 w-4 ml-2" />
              </Button>
            </div>
            <div>
              <h4 className="font-medium">Biosecurity Alert: Updated Protocols</h4>
              <p className="text-sm text-gray-600 mt-1">Important updates to biosecurity protocols for livestock transport and handling.</p>
              <Button variant="ghost" size="sm" className="mt-2">
                Read More
                <ExternalLink className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        </Card.Content>
      </Card>
    </div>
  );
}