import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';

export interface ReportOptions {
  format?: 'pdf' | 'excel' | 'csv';
  dateRange?: {
    start: Date;
    end: Date;
  };
  filters?: Record<string, any>;
}

export interface ReportData {
  title: string;
  data: any[];
  columns: string[];
}

export class ReportGenerator {
  static async generateReport(reportData: ReportData, options: ReportOptions = {}) {
    switch (options.format) {
      case 'pdf':
        return this.generatePDF(reportData);
      case 'excel':
        return this.generateExcel(reportData);
      case 'csv':
        return this.generateCSV(reportData);
      default:
        return this.generatePDF(reportData);
    }
  }

  private static async generatePDF(reportData: ReportData) {
    const doc = new jsPDF();
    
    // Add title
    doc.setFontSize(16);
    doc.text(reportData.title, 20, 20);

    // Add data table
    doc.setFontSize(12);
    let yPos = 40;
    
    // Add headers
    reportData.columns.forEach((column, index) => {
      doc.text(column, 20 + (index * 40), yPos);
    });
    
    // Add rows
    reportData.data.forEach((row, rowIndex) => {
      yPos += 10;
      reportData.columns.forEach((column, colIndex) => {
        doc.text(String(row[column]), 20 + (colIndex * 40), yPos);
      });
    });

    return doc.output('blob');
  }

  private static async generateExcel(reportData: ReportData) {
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(reportData.data);
    XLSX.utils.book_append_sheet(wb, ws, reportData.title);
    return XLSX.write(wb, { bookType: 'xlsx', type: 'buffer' });
  }

  private static async generateCSV(reportData: ReportData) {
    const headers = reportData.columns.join(',') + '\n';
    const rows = reportData.data.map(row => 
      reportData.columns.map(col => row[col]).join(',')
    ).join('\n');
    return headers + rows;
  }
}