export const reportTemplates = {
  stockInventory: {
    title: 'Stock Inventory Report',
    columns: [
      'Visual Tag',
      'NLIS ID',
      'Type',
      'Breed',
      'Sex',
      'Status',
      'Location',
      'Weight',
      'Purchase Cost',
      'Sale Price'
    ],
    filters: {
      dateRange: true,
      location: true,
      status: true
    }
  },
  treatments: {
    title: 'Treatment Records',
    columns: [
      'Date',
      'Visual Tag',
      'Treatment Type',
      'Product',
      'Batch Number',
      'Dosage',
      'WHP Start',
      'WHP End',
      'Operator'
    ],
    filters: {
      dateRange: true,
      treatmentType: true,
      operator: true
    }
  },
  movements: {
    title: 'Movement History',
    columns: [
      'Date',
      'From PIC',
      'To PIC',
      'NVD Number',
      'Number of Head',
      'Transport Details',
      'Status'
    ],
    filters: {
      dateRange: true,
      pic: true,
      status: true
    }
  },
  compliance: {
    title: 'Compliance Report',
    columns: [
      'Requirement',
      'Status',
      'Last Updated',
      'Next Review',
      'Responsible Person',
      'Comments'
    ],
    filters: {
      status: true,
      category: true
    }
  },
  feedEfficiency: {
    title: 'Feed Efficiency Report',
    columns: [
      'Date',
      'Feed Type',
      'Quantity Used',
      'Number of Head',
      'Average Weight Gain',
      'Cost per Head',
      'Conversion Rate'
    ],
    filters: {
      dateRange: true,
      feedType: true
    }
  }
};