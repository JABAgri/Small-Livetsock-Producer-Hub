import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './lib/auth/AuthContext';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import PrivateRoute from './components/auth/PrivateRoute';
import SignInForm from './components/auth/SignInForm';
import SignUpForm from './components/auth/SignUpForm';
import Dashboard from './components/Dashboard';
import StockManagement from './components/stock/StockManagement';
import NLISTransfer from './components/NLISTransfer';
import Education from './components/Education';
import Tools from './components/Tools';
import Resources from './components/Resources';
import ChemicalRegister from './components/ChemicalRegister';
import BiosecurityPlan from './components/BiosecurityPlan';
import DocumentTray from './components/DocumentTray';
import Reports from './components/Reports';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/signin" element={<SignInForm />} />
          <Route path="/signup" element={<SignUpForm />} />
          <Route path="/" element={<Navigate to="/dashboard" />} />
          
          <Route path="/dashboard" element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          } />
          <Route path="/stock" element={
            <PrivateRoute>
              <StockManagement />
            </PrivateRoute>
          } />
          <Route path="/nlis" element={
            <PrivateRoute>
              <NLISTransfer />
            </PrivateRoute>
          } />
          <Route path="/chemical" element={
            <PrivateRoute>
              <ChemicalRegister />
            </PrivateRoute>
          } />
          <Route path="/biosecurity" element={
            <PrivateRoute>
              <BiosecurityPlan />
            </PrivateRoute>
          } />
          <Route path="/education" element={
            <PrivateRoute>
              <Education />
            </PrivateRoute>
          } />
          <Route path="/tools" element={
            <PrivateRoute>
              <Tools />
            </PrivateRoute>
          } />
          <Route path="/resources" element={
            <PrivateRoute>
              <Resources />
            </PrivateRoute>
          } />
          <Route path="/documents" element={
            <PrivateRoute>
              <DocumentTray />
            </PrivateRoute>
          } />
          <Route path="/reports" element={
            <PrivateRoute>
              <Reports />
            </PrivateRoute>
          } />
        </Routes>
      </Router>
      <ToastContainer position="top-right" autoClose={3000} />
    </AuthProvider>
  );
}

export default App;