export default {
  expo: {
    name: "Livestock Hub",
    slug: "livestock-hub",
    version: "1.0.0",
    orientation: "default", // Allow both portrait and landscape
    icon: "./assets/icon.png",
    userInterfaceStyle: "light",
    splash: {
      image: "./assets/splash.png",
      resizeMode: "contain",
      backgroundColor: "#FAF6ED"
    },
    assetBundlePatterns: [
      "**/*"
    ],
    ios: {
      supportsTablet: true,
      bundleIdentifier: "com.jabagri.livestockhub",
      infoPlist: {
        UIRequiresFullScreen: false,
        UISupportedInterfaceOrientations: [
          "UIInterfaceOrientationPortrait",
          "UIInterfaceOrientationLandscapeLeft",
          "UIInterfaceOrientationLandscapeRight"
        ],
        UIRequiredDeviceCapabilities: [
          "armv7"
        ]
      }
    },
    android: {
      adaptiveIcon: {
        foregroundImage: "./assets/adaptive-icon.png",
        backgroundColor: "#FAF6ED"
      },
      package: "com.jabagri.livestockhub"
    },
    plugins: [
      [
        "expo-screen-orientation",
        {
          initialOrientation: "DEFAULT"
        }
      ],
      "expo-location",
      "expo-camera",
      "expo-document-picker"
    ]
  }
}