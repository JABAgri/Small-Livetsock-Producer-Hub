import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useWindowDimensions } from 'react-native';
import { Home, Database, FileText, Menu } from 'lucide-react-native';

import DashboardScreen from '../screens/DashboardScreen';
import StockManagementScreen from '../screens/StockManagementScreen';
import DocumentsScreen from '../screens/DocumentsScreen';
import MoreScreen from '../screens/MoreScreen';

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  const { width } = useWindowDimensions();
  const isLargeScreen = width >= 768;

  return (
    <Tab.Navigator
      screenOptions={{
        tabBarStyle: {
          backgroundColor: '#FAF6ED',
          borderTopColor: '#E6DCCA',
          height: isLargeScreen ? 60 : 50,
          paddingBottom: isLargeScreen ? 8 : 4,
        },
        tabBarActiveTintColor: '#CCAF9B',
        tabBarInactiveTintColor: '#666666',
        tabBarLabelStyle: {
          fontSize: isLargeScreen ? 14 : 12,
        },
        headerStyle: {
          backgroundColor: '#FAF6ED',
          borderBottomColor: '#E6DCCA',
          borderBottomWidth: 1,
          height: isLargeScreen ? 80 : 60,
        },
        headerTitleStyle: {
          fontSize: isLargeScreen ? 24 : 20,
        },
      }}
    >
      <Tab.Screen
        name="Dashboard"
        component={DashboardScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <Home size={isLargeScreen ? 28 : 24} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Stock"
        component={StockManagementScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <Database size={isLargeScreen ? 28 : 24} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Documents"
        component={DocumentsScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <FileText size={isLargeScreen ? 28 : 24} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="More"
        component={MoreScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <Menu size={isLargeScreen ? 28 : 24} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}