import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet, Linking } from 'react-native';
import { Text, Card, Button, TextInput } from 'react-native-paper';
import QRCode from 'react-native-qrcode-svg';
import * as DocumentPicker from 'expo-document-picker';
import { Upload, FileText, Download } from 'lucide-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function DocumentsScreen() {
  const [connectionCode, setConnectionCode] = useState('');
  const [webAppUrl, setWebAppUrl] = useState('');
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    // Check for existing connection
    checkConnection();

    // Handle deep linking
    const handleDeepLink = async (event: { url: string }) => {
      const url = new URL(event.url);
      const code = url.searchParams.get('code');
      const origin = url.searchParams.get('origin');
      if (code && origin) {
        await connectToWebApp(code, origin);
      }
    };

    // Listen for deep links
    Linking.addEventListener('url', handleDeepLink);
    
    // Check for initial URL
    Linking.getInitialURL().then(url => {
      if (url) {
        handleDeepLink({ url });
      }
    });

    return () => {
      // Clean up deep link listener
      Linking.removeAllListeners('url');
    };
  }, []);

  const checkConnection = async () => {
    try {
      const savedUrl = await AsyncStorage.getItem('webAppUrl');
      if (savedUrl) {
        setWebAppUrl(savedUrl);
        setIsConnected(true);
      }
    } catch (error) {
      console.error('Error checking connection:', error);
    }
  };

  const connectToWebApp = async (code: string, origin: string) => {
    try {
      // Validate connection code with web app
      const response = await fetch(`${origin}/api/validate-connection`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ code }),
      });

      if (response.ok) {
        await AsyncStorage.setItem('webAppUrl', origin);
        setWebAppUrl(origin);
        setIsConnected(true);
      }
    } catch (error) {
      console.error('Error connecting to web app:', error);
    }
  };

  const handleManualConnect = async () => {
    if (connectionCode.length === 6) {
      await connectToWebApp(connectionCode, webAppUrl);
    }
  };

  const handleDocumentPick = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/*'],
      });
      
      if (result.assets && result.assets.length > 0) {
        // Handle document upload to web app
        console.log(result.assets[0]);
      }
    } catch (err) {
      console.error('Error picking document:', err);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.cardTitle}>Web App Connection</Text>
          {!isConnected ? (
            <View style={styles.connectionForm}>
              <TextInput
                label="Connection Code"
                value={connectionCode}
                onChangeText={setConnectionCode}
                style={styles.input}
                maxLength={6}
                autoCapitalize="characters"
              />
              <Button
                mode="contained"
                onPress={handleManualConnect}
                style={styles.connectButton}
                disabled={connectionCode.length !== 6}
              >
                Connect
              </Button>
            </View>
          ) : (
            <View style={styles.connectedStatus}>
              <Text style={styles.connectedText}>Connected to Web App</Text>
              <Button
                mode="outlined"
                onPress={() => setIsConnected(false)}
                style={styles.disconnectButton}
              >
                Disconnect
              </Button>
            </View>
          )}
        </Card.Content>
      </Card>

      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.cardTitle}>Upload Documents</Text>
          <Button
            mode="outlined"
            icon={() => <Upload size={24} color="#CCAF9B" />}
            onPress={handleDocumentPick}
            style={styles.uploadButton}
          >
            Select Document
          </Button>
        </Card.Content>
      </Card>

      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.cardTitle}>Recent Documents</Text>
          <View style={styles.documentList}>
            <View style={styles.documentItem}>
              <View style={styles.documentInfo}>
                <FileText size={24} color="#CCAF9B" />
                <View style={styles.documentText}>
                  <Text>NVD_12345.pdf</Text>
                  <Text style={styles.timeText}>2 hours ago</Text>
                </View>
              </View>
              <Button
                mode="text"
                icon={() => <Download size={20} color="#CCAF9B" />}
              >
                Download
              </Button>
            </View>
          </View>
        </Card.Content>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAF6ED',
  },
  card: {
    margin: 8,
    backgroundColor: '#FFFFFF',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  connectionForm: {
    marginVertical: 16,
  },
  input: {
    marginBottom: 12,
    backgroundColor: '#FFFFFF',
  },
  connectButton: {
    backgroundColor: '#CCAF9B',
  },
  connectedStatus: {
    alignItems: 'center',
    marginVertical: 16,
  },
  connectedText: {
    fontSize: 16,
    color: '#4CAF50',
    marginBottom: 8,
  },
  disconnectButton: {
    borderColor: '#CCAF9B',
  },
  uploadButton: {
    borderColor: '#CCAF9B',
    borderStyle: 'dashed',
    height: 100,
    justifyContent: 'center',
  },
  documentList: {
    marginTop: 8,
  },
  documentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E6DCCA',
  },
  documentInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  documentText: {
    marginLeft: 12,
  },
  timeText: {
    fontSize: 12,
    color: '#666666',
  },
});