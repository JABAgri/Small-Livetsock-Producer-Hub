import React from 'react';
import { View, ScrollView, StyleSheet, useWindowDimensions } from 'react-native';
import { Text, Card, Button } from 'react-native-paper';
import MapView, { Marker } from 'react-native-maps';
import { Clock, AlertTriangle, CheckCircle, Activity } from 'lucide-react-native';
import { Layout } from '../components/Layout';

export default function DashboardScreen() {
  const { width } = useWindowDimensions();
  const isLargeScreen = width >= 768;

  return (
    <Layout>
      <ScrollView style={styles.container}>
        <View style={[
          styles.statsGrid,
          isLargeScreen && styles.statsGridTablet
        ]}>
          <Card style={[styles.statsCard, isLargeScreen && styles.statsCardTablet]}>
            <Card.Content>
              <Clock size={isLargeScreen ? 32 : 24} color="#CCAF9B" />
              <Text style={[styles.statsValue, isLargeScreen && styles.statsValueTablet]}>5</Text>
              <Text style={styles.statsLabel}>Tasks Due</Text>
            </Card.Content>
          </Card>

          {/* Similar adjustments for other stat cards */}
        </View>

        <View style={isLargeScreen && styles.splitView}>
          <Card style={[styles.mapCard, isLargeScreen && styles.mapCardTablet]}>
            <Card.Content>
              <Text style={styles.cardTitle}>Property Map</Text>
              <MapView
                style={[styles.map, isLargeScreen && styles.mapTablet]}
                initialRegion={{
                  latitude: -27.4698,
                  longitude: 153.0251,
                  latitudeDelta: 0.0922,
                  longitudeDelta: 0.0421,
                }}
              >
                <Marker
                  coordinate={{
                    latitude: -27.4698,
                    longitude: 153.0251,
                  }}
                />
              </MapView>
            </Card.Content>
          </Card>

          <View style={isLargeScreen && styles.sidePanel}>
            <Card style={styles.actionsCard}>
              <Card.Content>
                <Text style={styles.cardTitle}>Quick Actions</Text>
                <Button 
                  mode="outlined" 
                  style={styles.actionButton}
                  contentStyle={isLargeScreen && styles.actionButtonContentTablet}
                >
                  Record Movement
                </Button>
                <Button 
                  mode="outlined" 
                  style={styles.actionButton}
                  contentStyle={isLargeScreen && styles.actionButtonContentTablet}
                >
                  Add Treatment
                </Button>
                <Button 
                  mode="outlined" 
                  style={styles.actionButton}
                  contentStyle={isLargeScreen && styles.actionButtonContentTablet}
                >
                  Update NLIS
                </Button>
              </Card.Content>
            </Card>
          </View>
        </View>
      </ScrollView>
    </Layout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 8,
  },
  statsGridTablet: {
    padding: 16,
  },
  statsCard: {
    width: '48%',
    margin: '1%',
    backgroundColor: '#FFFFFF',
  },
  statsCardTablet: {
    width: '23%',
    margin: '1%',
    padding: 16,
  },
  statsValue: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 8,
  },
  statsValueTablet: {
    fontSize: 32,
  },
  statsLabel: {
    fontSize: 14,
    color: '#666666',
  },
  splitView: {
    flexDirection: 'row',
    padding: 16,
  },
  mapCard: {
    margin: 8,
    backgroundColor: '#FFFFFF',
  },
  mapCardTablet: {
    flex: 2,
    margin: 0,
    marginRight: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  map: {
    height: 200,
    marginVertical: 8,
    borderRadius: 8,
  },
  mapTablet: {
    height: 400,
  },
  sidePanel: {
    flex: 1,
  },
  actionsCard: {
    margin: 8,
    backgroundColor: '#FFFFFF',
  },
  actionButton: {
    marginVertical: 4,
    borderColor: '#CCAF9B',
  },
  actionButtonContentTablet: {
    height: 48,
  },
});