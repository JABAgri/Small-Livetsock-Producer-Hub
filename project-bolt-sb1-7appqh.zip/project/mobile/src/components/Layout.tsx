import React from 'react';
import { View, StyleSheet, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export const Layout = ({ children }) => {
  const { width } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const isLargeScreen = width >= 768; // iPad mini and larger

  return (
    <View 
      style={[
        styles.container,
        {
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
          paddingLeft: isLargeScreen ? 20 : insets.left,
          paddingRight: isLargeScreen ? 20 : insets.right,
          maxWidth: isLargeScreen ? 1024 : '100%',
          alignSelf: 'center',
          width: '100%'
        }
      ]}
    >
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAF6ED',
  },
});