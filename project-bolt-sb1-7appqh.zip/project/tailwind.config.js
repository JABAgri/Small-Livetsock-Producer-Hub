/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#FDFBF7',
          100: '#FAF6ED',
          200: '#F5ECD8',
          300: '#EFE2C3',
          400: '#E9D8AE',
          500: '#E3CE99',
        },
        coffee: {
          50: '#FAF7F5',
          100: '#F5EFEB',
          200: '#EBDFD7',
          300: '#E0CFC3',
          400: '#D6BFAF',
          500: '#CCAF9B',
        },
        sand: {
          50: '#FDFCFA',
          100: '#FAF8F5',
          200: '#F5F1EA',
          300: '#F0EAE0',
          400: '#EBE3D5',
          500: '#E6DCCA',
        }
      }
    },
  },
  plugins: [],
};